/* ============================================================
   McGUFFIN PRESS — SHOP PRODUCTS
   ============================================================
   This is the ONLY file you edit to change the shop.
   The homepage builds the shop cards automatically from the
   list below. Add, remove, or reorder products here and save.

   ── HOW TO ADD A PRODUCT ──────────────────────────────────
   Copy one { ... } block below (including the comma), paste it
   inside the [ ] list, and change the values. Fields:

     type        Small label above the title  (e.g. "Hardback", "Merch", "Map")
     title       Product name. You may use <em>italics</em>.
     description One or two sentences.
     price       e.g. "$19.99"   — or "" to hide the price line
     priceNote   e.g. "+ applicable taxes"   — or "" for none
     image       Path to a product photo in /assets  (e.g. "assets/cusp-born-cover.jpg")
                 — or "" to show an emoji instead
     emoji       Shown when there is no image  (e.g. "🗺️", "✦", "👕")
     style       "cover"   = stand a book cover upright (for books)
                 "product" = fill the box with the photo (for merch)
     badge       Corner ribbon text  (e.g. "First Edition") — or "" for none
     status      "available"   = shows a Buy button (needs buyLink)
                 "coming-soon" = shows a greyed "Coming Soon"
                 "notify"      = shows a "Get Notified" button (needs notifyLink)
     buyLink     Your Square payment link  (only used when status = "available")
     buyLabel    Button text  (default "Buy Now →")
     notifyLink  Link for "Get Notified" (e.g. your Kit form URL)

   Tip: get a Square link at  squareup.com → Online → Payment Links.
   ============================================================ */

const SHOP_PRODUCTS = [

  {
    type: "Hardback",
    title: "First Edition Hardback — <em>Cusp Born</em>",
    description: "A stunning hardback of Lorraine Hawley's middle-grade fantasy, with cover art and illustrations by Jocie Salveson. UV spot-gloss cover.",
    price: "$19.99",
    priceNote: "+ applicable taxes",
    image: "assets/cusp-born-cover.jpg",
    emoji: "",
    style: "cover",
    badge: "First Edition",
    status: "available",
    buyLink: "https://square.link/u/IQ3vCLtN",
    buyLabel: "Buy Now →",
    notifyLink: ""
  },

  {
    type: "Collectible Map",
    title: "Zodiac Realm Map",
    description: "A beautifully illustrated map of the Zodiac Realm from <em>Cusp Born</em>, rendered by illustrator Mark Sean Wilson. A must-have for fans of the series.",
    price: "",
    priceNote: "",
    image: "",
    emoji: "🗺️",
    style: "product",
    badge: "Coming Soon",
    status: "notify",
    buyLink: "",
    buyLabel: "Buy Now →",
    notifyLink: "https://app.kit.com/forms/9104405/subscriptions"
  }

  /* ,  ← remember a comma before each new block

  {
    type: "Merch",
    title: "Example Product",
    description: "Describe it here.",
    price: "$24.99",
    priceNote: "+ shipping",
    image: "assets/your-photo.jpg",
    emoji: "✦",
    style: "product",
    badge: "",
    status: "available",
    buyLink: "https://square.link/u/XXXXXXXX",
    buyLabel: "Buy Now →",
    notifyLink: ""
  }
  */

];
