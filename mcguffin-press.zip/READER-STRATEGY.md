# McGuffin Press — Reader-First Website Strategy

*Prepared 2026-06-18 · Debut title: "Cusp Born" by Lorraine Hawley (upper middle-grade fantasy, ages 8–12, illustrated by Jocie Salveson) · Newsletter: Kit*

---

## 1. Executive Summary

McGuffin Press has just reoriented its website from **author acquisition** (query letters, submission guidance, "how to get published" content) to **reader and educational acquisition** (reading lists, family reading guides, classroom and library resources). This document is the playbook for that pivot.

**The pivot.** The old site treated authors as the primary audience — its content engine, lead magnets, and resource center were built to attract writers. That audience does not buy books; it sells them. The new site flips this: the people we want on the page are parents buying a birthday gift, a homeschool mom planning next year's literature block, a fourth-grade teacher hunting for a read-aloud, and a youth-services librarian building a fantasy display. Authors remain served (the `/submit` page stays) but are now a distant fourth priority.

**The single-title realism.** We must be honest about where we are: **McGuffin has exactly one published book.** *Cusp Born* is excellent and well-positioned (illustrated upper-MG fantasy, the most reliably purchased and assigned children's genre), but one title cannot anchor a publisher-as-destination strategy by itself. This creates a structural tension that runs through every section below:

- **Broad reader-discovery content** ("best read-aloud chapter books," "middle grade books about courage," "summer reading list by grade") will attract the most traffic and the most email signups. It converts to McGuffin *sales* **weakly** today, because most search intent is satisfied by recommending many books, most of which we don't publish. That is fine — its job is **audience and list growth**, not immediate revenue.
- **Cusp-Born-specific resources** (discussion guide, lesson plan, read-aloud notes, vocabulary list, author info sheet) convert **strongly** but at **low volume**, and they are the only assets that win classroom, library, homeschool, and book-club *adoption* of the actual title.

**The thesis.** Use broad reader-discovery content to build an email audience and SEO authority *now*, while every page funnels toward two anchored conversions: (1) buy *Cusp Born*, and (2) subscribe to the Kit newsletter. Treat *Cusp Born* as the flagship case study for an **institutional resource kit** that wins adoption today and becomes a **repeatable template** for every future title. As the catalog grows from one book to a list, the broad content that was "weak-converting traffic" becomes a genuine catalog-discovery funnel — we are building the audience ahead of the catalog on purpose.

**What success looks like in 12 months:** a Kit list in the low thousands, organic search as the #1 traffic source, *Cusp Born* selling steadily through both consumer and institutional channels, and at least one validated repeatable institutional kit ready to drop onto book #2 the day it's announced.

---

## 2. Audience & Funnel

Four audiences, in priority order. For each: where they enter, what serves them, and what we want them to do.

| Priority | Audience | Discovery Entry Point | Resource That Serves Them | Conversion Goal |
|---|---|---|---|---|
| **PRIMARY** | **Readers & book buyers** — parents, grandparents, gift buyers, avid MG readers | Google searches like "best fantasy books for 10 year olds," gift-guide content, Pinterest, the homepage | Reading Lists, For Families, the *Cusp Born* book page, Family Reading Guide lead magnet | **Buy** *Cusp Born* + **subscribe** to Kit |
| **SECONDARY** | **Educational buyers** — homeschool families, teachers, reading specialists, curriculum planners | Searches like "middle grade novel studies," "homeschool literature curriculum," "classroom read-aloud chapter books" | Homeschool section, For Educators (Teacher Resources), Homeschool Literature Resource Pack, Teacher Discussion Guide Collection | **Adopt** *Cusp Born* for classroom/curriculum + **subscribe** + bulk **buy** |
| **TERTIARY** | **Institutional** — librarians, book clubs, reading groups | Searches like "middle grade book club picks," "library reading program ideas," ALA/CSLP-adjacent content | For Libraries, Book Clubs, Book Club Starter Kit, the *Cusp Born* Educators & Librarians Kit | **Adopt** *Cusp Born* (collection / club pick / display) + **subscribe** |
| **FOURTH** | **Authors** (submissions only) | `/submit`, "submit middle grade manuscript [publisher]" | Submit page only | Submit a qualifying manuscript (no longer a content focus) |

**Funnel logic.** Discovery (broad SEO content + lead magnets) → Capture (Kit signup via gated/soft-gated lead magnets and inline forms) → Nurture (Kit welcome sequence + monthly newsletter that recommends books and surfaces *Cusp Born*) → Convert (buy / adopt) → Advocate (reviews, classroom word-of-mouth, gift repeat-purchase). The newsletter is the connective tissue: broad content earns the email, the email sells the book over time.

---

## 3. Keyword Strategy (reader-discovery)

Target clusters chosen for reader and educational intent. Difficulty is relative to a small new-domain publisher; **P0** = pursue immediately (achievable + on-thesis), **P3** = long-term/aspirational. No author/publishing/query terms.

| # | Keyword | Audience | Difficulty | Priority | Target Page |
|---|---|---|---|---|---|
| 1 | best read aloud chapter books | Reader | High | P0 | /resources/reading-lists/ |
| 2 | middle grade book recommendations | Reader | High | P0 | /resources/reading-lists/ |
| 3 | fantasy books for 10 year olds | Reader | Med | P0 | /resources/reading-lists/fantasy-books-age-10.html |
| 4 | books for reluctant readers age 8-12 | Reader | Med | P0 | /resources/reading-lists/reluctant-readers.html |
| 5 | children's books about courage | Reader | Med | P0 | /resources/reading-lists/books-about-courage.html |
| 6 | children's books about friendship | Reader | Med | P0 | /resources/reading-lists/books-about-friendship.html |
| 7 | best books for 4th graders | Reader | High | P1 | /resources/reading-lists/best-books-4th-grade.html |
| 8 | upper middle grade fantasy books | Reader | Med | P0 | /resources/reading-lists/upper-middle-grade-fantasy.html |
| 9 | gift books for 9 year olds | Reader | Med | P1 | /resources/reading-lists/book-gifts-age-9.html |
| 10 | family reading guide | Reader/Family | Low | P0 | /resources/downloads/ (Family Reading Guide) |
| 11 | how to do a family read aloud | Family | Low | P0 | /resources/for-families/family-read-aloud-guide.html |
| 12 | summer reading list middle grade | Reader/Educator | Med | P0 | /resources/reading-lists/summer-reading-middle-grade.html |
| 13 | summer reading challenge for kids | Family | Med | P0 | /resources/downloads/ (Summer Reading Challenge) |
| 14 | reading by grade level chart | Educator/Family | Med | P1 | /resources/for-families/reading-by-grade-level.html |
| 15 | how to raise a reader | Family | High | P2 | /resources/for-families/ |
| 16 | screen-free activities for kids reading | Family | Med | P2 | /resources/for-families/ |
| 17 | homeschool literature curriculum | Homeschool | High | P0 | /resources/homeschool/ |
| 18 | homeschool reading list middle grade | Homeschool | Med | P0 | /resources/homeschool/homeschool-reading-list.html |
| 19 | living books for middle school | Homeschool | Med | P1 | /resources/homeschool/living-books-middle-grade.html |
| 20 | how to teach a novel at home | Homeschool | Med | P1 | /resources/homeschool/teaching-a-novel-at-home.html |
| 21 | homeschool literature unit study | Homeschool | Med | P0 | /resources/downloads/ (Homeschool Lit Resource Pack) |
| 22 | charlotte mason book lists | Homeschool | Med | P2 | /resources/homeschool/charlotte-mason-book-list.html |
| 23 | classroom read aloud chapter books | Educator | High | P0 | /resources/for-educators/classroom-read-alouds.html |
| 24 | middle grade novel study | Educator | Med | P0 | /resources/for-educators/novel-study-guide.html |
| 25 | free novel study guides | Educator | High | P1 | /resources/downloads/ (Teacher Discussion Guide Collection) |
| 26 | books to teach theme 5th grade | Educator | Med | P1 | /resources/for-educators/teaching-theme-middle-grade.html |
| 27 | discussion questions for chapter books | Educator | Med | P0 | /resources/for-educators/discussion-questions.html |
| 28 | reading specialist book recommendations | Educator | Low | P1 | /resources/for-educators/ |
| 29 | classroom library must haves middle grade | Educator | Med | P2 | /resources/for-educators/classroom-library-list.html |
| 30 | teacher discussion guide collection | Educator | Low | P0 | /resources/downloads/ |
| 31 | library reading lists for kids | Library | Med | P1 | /resources/for-libraries/library-reading-lists.html |
| 32 | summer reading program ideas library | Library | Med | P1 | /resources/for-libraries/summer-reading-program.html |
| 33 | middle grade books for library collection | Library | Med | P0 | /resources/for-libraries/ |
| 34 | book display ideas middle grade | Library | Med | P2 | /resources/for-libraries/book-display-ideas.html |
| 35 | book club discussion guides middle grade | Book Club | Med | P0 | /resources/book-clubs/discussion-guides.html |
| 36 | book club books for kids | Book Club | Med | P0 | /resources/book-clubs/kids-book-club-picks.html |
| 37 | how to start a kids book club | Book Club | Low | P0 | /resources/book-clubs/how-to-start-a-book-club.html |
| 38 | mother daughter book club books | Book Club | Med | P1 | /resources/book-clubs/mother-daughter-book-club.html |
| 39 | book club starter kit | Book Club | Low | P0 | /resources/downloads/ (Book Club Starter Kit) |
| 40 | cusp born lorraine hawley | Reader | Low | P0 | /cusp-born.html |
| 41 | new middle grade fantasy 2026 | Reader | Med | P1 | /resources/reading-lists/new-middle-grade-fantasy.html |
| 42 | books like percy jackson for younger readers | Reader | High | P1 | /resources/reading-lists/books-like-percy-jackson.html |
| 43 | strong girl protagonist middle grade | Reader | Med | P1 | /resources/reading-lists/girl-protagonist-fantasy.html |
| 44 | back to school reading list | Educator/Family | Med | P1 | /resources/reading-lists/back-to-school-reading-list.html |
| 45 | holiday gift guide for young readers | Reader | Med | P1 | /resources/reading-lists/holiday-book-gift-guide.html |

---

## 4. On-Page SEO Specification

Polished, ready-to-paste copy for the core pages. Meta titles ≤60 chars, meta descriptions ≤155 chars.

| Page | Recommended H1 | Meta Title (≤60) | Meta Description (≤155) | Primary Keyword | Key H2s |
|---|---|---|---|---|---|
| **/** (Homepage) | Books That Stay With Young Readers | McGuffin Press — Books & Reading Resources for Kids | Independent publisher of middle-grade fiction, plus free reading lists, family guides, and classroom resources for ages 8–12. | middle grade book recommendations | Meet Cusp Born · Free Reading Resources · For Families & Educators · Join Our Reading Newsletter |
| **/cusp-born.html** | Cusp Born by Lorraine Hawley | Cusp Born by Lorraine Hawley — MG Fantasy (Ages 8–12) | A spellbinding upper middle-grade fantasy for ages 8–12, illustrated by Jocie Salveson. Read an excerpt, buy the book, get the discussion guide. | cusp born lorraine hawley | The Story · For Readers Ages 8–12 · For Teachers & Librarians · Read an Excerpt · Buy Cusp Born |
| **/resources/** | The McGuffin Reader Resource Center | Free Reading Resources — Lists, Guides & Lesson Plans | Free reading lists, family reading guides, homeschool resources, and classroom lesson plans for young readers ages 8–12. | reading resources for kids | Reading Lists · For Families · Homeschool · For Educators · For Libraries · Book Clubs · Free Downloads |
| **/resources/reading-lists/** | Reading Lists for Ages 8–12 | Middle Grade Reading Lists by Age, Grade & Theme | Curated middle-grade reading lists by age, grade, and theme — read-alouds, reluctant readers, fantasy, friendship, courage, and more. | middle grade book recommendations | By Age & Grade · By Theme · Read-Aloud Favorites · For Reluctant Readers · Seasonal Lists |
| **/resources/for-families/** | Reading Resources for Families | Family Reading Guides — Read-Alouds & Raising Readers | Practical guides to reading aloud, building reading habits, and choosing the right books for your child, ages 8–12. | family reading guide | How to Read Aloud · Reading by Grade Level · Building a Reading Habit · Get the Free Family Reading Guide |
| **/resources/homeschool/** | Homeschool Literature Resources | Homeschool Literature — Reading Lists & Unit Studies | Literature-based reading lists, novel studies, and unit-study resources for homeschooling families teaching ages 8–12. | homeschool literature curriculum | Reading Lists by Grade · Novel Studies · Living Books · Unit Studies · Free Homeschool Resource Pack |
| **/resources/for-educators/** | Teacher Resources for Reading | Teacher Resources — Read-Alouds & Novel Studies | Free classroom read-aloud lists, novel-study guides, and discussion questions for teaching middle-grade fiction. | classroom read aloud chapter books | Classroom Read-Alouds · Novel Studies · Discussion Questions · Building a Classroom Library · Free Guide Collection |
| **/resources/for-libraries/** | Resources for Librarians | Library Resources — Reading Lists & Program Ideas | Collection-ready middle-grade reading lists, summer reading program ideas, and display kits for youth-services librarians. | middle grade books for library collection | Collection Development Lists · Summer Reading Programs · Display Ideas · Program Kits · Request the Cusp Born Kit |
| **/resources/book-clubs/** | Book Club Resources for Young Readers | Kids' Book Club Guides, Picks & Starter Kit | Discussion guides, curated picks, and a free starter kit for running a kids' or family book club, ages 8–12. | book club discussion guides middle grade | How to Start a Book Club · Discussion Guides · Curated Picks · Mother-Daughter Clubs · Free Starter Kit |
| **/resources/downloads/** | Free Reading Resource Downloads | Free Reading Guides & Printables for Kids | Download free reading resources: family reading guide, summer reading challenge, homeschool pack, teacher guides, and a book club kit. | free reading printables for kids | Family Reading Guide · Summer Reading Challenge · Homeschool Literature Pack · Teacher Guide Collection · Book Club Starter Kit |

---

## 5. Content Engine — 100 Article/Resource Ideas

Evergreen reader/educational content. Scores are 1–5. **SEO Value** = search demand × winnability; **Book-Buyer / Educator / Homeschool Pull** = how strongly each piece moves that audience toward a McGuffin conversion or signup. Priority weights on-thesis pieces (audience growth now, *Cusp Born* anchoring) highest.

| # | Title | Category | Primary Keyword | SEO | Buyer | Educ | HS | Priority |
|---|---|---|---|---|---|---|---|---|
| 1 | 25 Best Read-Aloud Chapter Books for Ages 8–12 | Reading List | best read aloud chapter books | 5 | 5 | 5 | 5 | P0 |
| 2 | The Best Middle Grade Fantasy Books for 10-Year-Olds | Reading List | fantasy books for 10 year olds | 5 | 5 | 3 | 4 | P0 |
| 3 | 20 Books for Reluctant Readers (Ages 8–12) | Reading List | books for reluctant readers | 4 | 5 | 5 | 4 | P0 |
| 4 | Middle Grade Books About Courage and Bravery | Reading List | children's books about courage | 4 | 5 | 4 | 4 | P0 |
| 5 | Middle Grade Books About Friendship | Reading List | children's books about friendship | 4 | 5 | 4 | 4 | P0 |
| 6 | The Ultimate Summer Reading List for Middle Graders | Reading List | summer reading list middle grade | 5 | 5 | 4 | 4 | P0 |
| 7 | Best Books for 4th Graders (Teacher-Approved) | Reading List | best books for 4th graders | 4 | 4 | 5 | 4 | P1 |
| 8 | Best Books for 5th Graders by Reading Level | Reading List | best books for 5th graders | 4 | 4 | 5 | 4 | P1 |
| 9 | Upper Middle Grade Fantasy: A Starter Reading List | Reading List | upper middle grade fantasy books | 4 | 5 | 3 | 3 | P0 |
| 10 | Book Gift Guide for 9-Year-Olds | Reading List | gift books for 9 year olds | 4 | 5 | 1 | 2 | P1 |
| 11 | Holiday Gift Guide: Best Books for Young Readers | Reading List | holiday gift guide young readers | 4 | 5 | 1 | 2 | P1 |
| 12 | New Middle Grade Fantasy to Watch in 2026 | Reading List | new middle grade fantasy 2026 | 3 | 4 | 2 | 2 | P1 |
| 13 | Books Like Percy Jackson for Younger Readers | Reading List | books like percy jackson | 4 | 5 | 2 | 3 | P1 |
| 14 | Middle Grade Books With Strong Girl Protagonists | Reading List | strong girl protagonist middle grade | 4 | 5 | 3 | 3 | P1 |
| 15 | First Chapter Books for Newly Independent Readers | Reading List | first chapter books | 4 | 4 | 4 | 4 | P1 |
| 16 | Back-to-School Reading List for Ages 8–12 | Reading List | back to school reading list | 4 | 4 | 5 | 4 | P1 |
| 17 | Cozy Fall Reads for Middle Graders | Reading List | fall books for kids | 3 | 4 | 2 | 3 | P2 |
| 18 | Winter & Holiday Chapter Books for Kids | Reading List | winter chapter books for kids | 3 | 4 | 2 | 3 | P2 |
| 19 | Middle Grade Books About Family and Belonging | Reading List | books about family for kids | 3 | 4 | 4 | 4 | P1 |
| 20 | Books That Build Empathy in Middle Grade Readers | Reading List | books that teach empathy | 3 | 4 | 5 | 4 | P1 |
| 21 | Fantasy Books for Kids Who Love Magic Systems | Reading List | magic books for kids | 3 | 4 | 2 | 2 | P2 |
| 22 | Standalone Middle Grade Novels (No Series Commitment) | Reading List | standalone middle grade books | 3 | 4 | 3 | 3 | P2 |
| 23 | Best Illustrated Chapter Books for Ages 8–12 | Reading List | illustrated chapter books | 4 | 5 | 4 | 4 | P0 |
| 24 | Diverse Middle Grade Books for Every Classroom | Reading List | diverse middle grade books | 4 | 4 | 5 | 4 | P1 |
| 25 | Award-Worthy Middle Grade Reads of the Year | Reading List | best middle grade books year | 3 | 4 | 3 | 3 | P2 |
| 26 | Books for Kids Who Finished Harry Potter | Reading List | books after harry potter | 4 | 5 | 2 | 3 | P1 |
| 27 | Adventure Books for Middle Grade Readers | Reading List | adventure books for kids | 3 | 4 | 3 | 3 | P2 |
| 28 | Quiet, Thoughtful Books for Introverted Readers | Reading List | books for introverted kids | 3 | 4 | 3 | 3 | P2 |
| 29 | Books to Read Aloud in Under a Month | Reading List | short read aloud books | 3 | 3 | 5 | 4 | P2 |
| 30 | Middle Grade Books About Growing Up & Change | Reading List | coming of age middle grade | 3 | 4 | 4 | 4 | P1 |
| 31 | How to Read Aloud to Older Kids (and Why It Matters) | Family | how to read aloud to kids | 4 | 4 | 4 | 5 | P0 |
| 32 | Building a Daily Reading Habit at Home | Family | reading habit for kids | 4 | 3 | 3 | 4 | P1 |
| 33 | What to Do When Your Child Won't Read | Family | child won't read | 4 | 4 | 3 | 4 | P0 |
| 34 | Reading by Grade Level: A Parent's Chart | Family | reading by grade level | 4 | 3 | 4 | 4 | P1 |
| 35 | How to Choose the Right Book for Your Child's Level | Family | choosing books for kids | 4 | 4 | 3 | 4 | P1 |
| 36 | Screen-Free Reading Activities for the Whole Family | Family | screen free activities reading | 3 | 3 | 2 | 4 | P2 |
| 37 | Setting Up a Cozy Reading Nook for Kids | Family | reading nook for kids | 3 | 3 | 1 | 3 | P2 |
| 38 | How to Talk to Your Child About a Book | Family | talking about books with kids | 3 | 3 | 4 | 4 | P1 |
| 39 | Grandparents' Guide to Gifting Books Kids Love | Family | book gifts from grandparents | 3 | 5 | 1 | 2 | P1 |
| 40 | Reading Aloud With Multiple Ages at Once | Family | read aloud multiple ages | 3 | 3 | 3 | 5 | P1 |
| 41 | How to Run a Family Read-Aloud Night | Family | family read aloud night | 3 | 4 | 2 | 4 | P1 |
| 42 | Keeping Kids Reading Over Summer Break | Family | summer reading kids | 4 | 4 | 4 | 4 | P0 |
| 43 | Books That Spark Great Family Conversations | Family | books for family discussion | 3 | 4 | 3 | 4 | P1 |
| 44 | How Many Books Should a Child Read in a Year? | Family | how many books should kids read | 3 | 3 | 3 | 3 | P2 |
| 45 | Audiobooks vs. Print for Young Readers | Family | audiobooks for kids reading | 3 | 3 | 3 | 3 | P2 |
| 46 | Helping a Perfectionist Child Enjoy Reading | Family | reluctant perfectionist reader | 2 | 3 | 3 | 3 | P3 |
| 47 | A Homeschool Literature Reading List (Ages 8–12) | Homeschool | homeschool reading list | 5 | 4 | 4 | 5 | P0 |
| 48 | How to Teach a Novel at Home (Step by Step) | Homeschool | how to teach a novel at home | 4 | 3 | 4 | 5 | P0 |
| 49 | Living Books for Middle Grade Learners | Homeschool | living books middle grade | 4 | 3 | 3 | 5 | P0 |
| 50 | Building a Literature-Based Homeschool Curriculum | Homeschool | literature based curriculum | 4 | 3 | 4 | 5 | P1 |
| 51 | How to Create a Novel Unit Study | Homeschool | novel unit study | 4 | 3 | 4 | 5 | P0 |
| 52 | Charlotte Mason Book List for Ages 8–12 | Homeschool | charlotte mason book list | 4 | 3 | 2 | 5 | P1 |
| 53 | Narration & Copywork With Middle Grade Novels | Homeschool | narration copywork novels | 3 | 2 | 3 | 5 | P1 |
| 54 | A Homeschool Reading Schedule You'll Actually Keep | Homeschool | homeschool reading schedule | 3 | 2 | 3 | 5 | P1 |
| 55 | Fantasy Novels Worth Studying in Homeschool | Homeschool | homeschool fantasy literature | 3 | 4 | 3 | 5 | P1 |
| 56 | How to Assess Reading Without Tests | Homeschool | assess reading comprehension homeschool | 3 | 2 | 4 | 5 | P1 |
| 57 | Combining Grade Levels for Literature Study | Homeschool | multi-age homeschool literature | 3 | 2 | 3 | 5 | P2 |
| 58 | Free Homeschool Literature Printables & Templates | Homeschool | homeschool literature printables | 4 | 2 | 3 | 5 | P0 |
| 59 | Vocabulary Study Using Middle Grade Novels | Homeschool | vocabulary from novels | 3 | 2 | 4 | 5 | P1 |
| 60 | Teaching Theme & Symbolism to Middle Graders | Homeschool | teaching theme middle grade | 3 | 2 | 5 | 5 | P1 |
| 61 | A Year of Read-Alouds for Homeschoolers | Homeschool | homeschool read aloud list | 4 | 4 | 3 | 5 | P0 |
| 62 | How to Lead a Literature Discussion at Home | Homeschool | literature discussion homeschool | 3 | 2 | 4 | 5 | P1 |
| 63 | Best Chapter Book Read-Alouds for the Classroom | Educator | classroom read aloud chapter books | 5 | 3 | 5 | 3 | P0 |
| 64 | How to Run a Middle Grade Novel Study | Educator | middle grade novel study | 4 | 2 | 5 | 4 | P0 |
| 65 | 50 Discussion Questions for Any Chapter Book | Educator | discussion questions chapter books | 4 | 2 | 5 | 4 | P0 |
| 66 | Building a Standout Classroom Library (Grades 3–6) | Educator | classroom library middle grade | 4 | 3 | 5 | 2 | P1 |
| 67 | Teaching Reading Comprehension With Fiction | Educator | teaching reading comprehension | 4 | 1 | 5 | 3 | P1 |
| 68 | Read-Aloud Strategies That Hook Every Student | Educator | read aloud strategies classroom | 3 | 2 | 5 | 3 | P1 |
| 69 | How to Choose a Whole-Class Novel | Educator | choosing class novel | 3 | 2 | 5 | 3 | P1 |
| 70 | Literature Circles: A Teacher's Setup Guide | Educator | literature circles setup | 4 | 2 | 5 | 3 | P1 |
| 71 | Vocabulary Activities for Middle Grade Novels | Educator | novel vocabulary activities | 3 | 1 | 5 | 4 | P1 |
| 72 | Pairing Fiction With Writing Prompts | Educator | reading writing prompts | 3 | 1 | 5 | 3 | P2 |
| 73 | Differentiating a Novel Study for Mixed Abilities | Educator | differentiated novel study | 3 | 1 | 5 | 3 | P2 |
| 74 | Free Printable Novel Study Templates for Teachers | Educator | free novel study templates | 4 | 1 | 5 | 4 | P0 |
| 75 | Using Fantasy to Teach Story Structure | Educator | teaching story structure fantasy | 3 | 3 | 5 | 4 | P1 |
| 76 | Assessment Ideas Beyond the Book Report | Educator | alternatives to book reports | 3 | 1 | 5 | 4 | P1 |
| 77 | Reading Specialist's Guide to Engaging Strugglers | Educator | reluctant reader interventions | 3 | 2 | 5 | 3 | P2 |
| 78 | Best First-Week-of-School Read-Alouds | Educator | first week read alouds | 3 | 2 | 5 | 2 | P1 |
| 79 | How to Run a Classroom Book Tasting | Educator | classroom book tasting | 3 | 3 | 5 | 2 | P2 |
| 80 | Connecting Novels to Social-Emotional Learning | Educator | SEL through literature | 3 | 2 | 5 | 3 | P2 |
| 81 | Middle Grade Books Perfect for Library Collections | Library | middle grade library collection | 4 | 2 | 4 | 2 | P0 |
| 82 | Summer Reading Program Ideas That Actually Work | Library | summer reading program ideas | 4 | 2 | 4 | 2 | P1 |
| 83 | Middle Grade Book Display Ideas for Libraries | Library | library book display ideas | 3 | 2 | 3 | 1 | P2 |
| 84 | Building a Diverse Youth Fiction Collection | Library | diverse youth collection development | 3 | 2 | 4 | 1 | P2 |
| 85 | How to Run a Library Book Club for Kids | Library | library kids book club | 3 | 2 | 4 | 2 | P1 |
| 86 | Pairing New Releases With Beloved Backlist | Library | library readers advisory | 3 | 3 | 3 | 1 | P2 |
| 87 | Readers' Advisory Cheat Sheet for Middle Grade | Library | readers advisory middle grade | 3 | 2 | 4 | 2 | P1 |
| 88 | Hosting a Local Author Visit at Your Library | Library | author visit library | 2 | 3 | 3 | 1 | P3 |
| 89 | Supporting Homeschoolers Through Your Library | Library | library homeschool support | 2 | 2 | 3 | 4 | P2 |
| 90 | National Library Week Program Ideas | Library | national library week ideas | 3 | 1 | 3 | 1 | P2 |
| 91 | How to Start a Kids' Book Club (Complete Guide) | Book Club | how to start a kids book club | 4 | 4 | 3 | 3 | P0 |
| 92 | 15 Great Book Club Picks for Ages 8–12 | Book Club | book club books for kids | 4 | 5 | 3 | 3 | P0 |
| 93 | Mother-Daughter Book Club: Books & Discussion Tips | Book Club | mother daughter book club | 4 | 5 | 2 | 3 | P1 |
| 94 | Writing Great Book Club Discussion Questions | Book Club | book club discussion questions | 4 | 3 | 4 | 3 | P0 |
| 95 | Snacks, Crafts & Activities for Kids' Book Clubs | Book Club | book club activities for kids | 3 | 4 | 2 | 3 | P2 |
| 96 | Running a Parent-Child Book Club That Lasts | Book Club | parent child book club | 3 | 4 | 2 | 3 | P1 |
| 97 | Fantasy Book Club Picks for Middle Graders | Book Club | fantasy book club kids | 3 | 5 | 2 | 3 | P1 |
| 98 | A 6-Month Book Club Reading Plan for Kids | Book Club | book club reading plan kids | 3 | 4 | 3 | 3 | P1 |
| 99 | How to Keep Kids Engaged in Book Club Discussion | Book Club | book club discussion tips | 3 | 3 | 3 | 3 | P2 |
| 100 | First Meeting Guide: Launching Your Book Club | Book Club | first book club meeting | 3 | 4 | 2 | 3 | P1 |

*Row count: 100 (verified — IDs 1–100, contiguous).*

---

## 6. 12-Month Content Calendar

Starting July 2026. Each month publishes 3–4 pieces from the 100 above, with one lead-magnet push tied to a seasonal hook. Numbers in parentheses reference Section 5 IDs.

| Month | Theme | Resource/Article Titles | Lead Magnet Push | Seasonal Hook |
|---|---|---|---|---|
| **Jul 2026** | Summer Reading | Ultimate Summer Reading List for Middle Graders (6) · Keeping Kids Reading Over Summer (42) · Books for Reluctant Readers (3) | **Summer Reading Challenge** | Peak summer reading season |
| **Aug 2026** | Back to School | Best Chapter Book Read-Alouds for the Classroom (63) · Back-to-School Reading List (16) · Best First-Week-of-School Read-Alouds (78) · How to Run a Novel Study (64) | **Teacher Discussion Guide Collection** | Back-to-school (educators planning) |
| **Sep 2026** | Classroom & Homeschool Launch | Homeschool Literature Reading List (47) · 50 Discussion Questions for Any Chapter Book (65) · How to Teach a Novel at Home (48) · Free Printable Novel Study Templates (74) | **Homeschool Literature Resource Pack** | New school/homeschool year underway |
| **Oct 2026** | Read-Aloud & Cozy Season | 25 Best Read-Aloud Chapter Books (1) · Cozy Fall Reads (17) · How to Read Aloud to Older Kids (31) | **Family Reading Guide** | Fall read-aloud / cozy season |
| **Nov 2026** | Gift Guides | Holiday Gift Guide: Best Books for Young Readers (11) · Grandparents' Guide to Gifting Books (39) · Book Gift Guide for 9-Year-Olds (10) | **Family Reading Guide** (gift framing) | Holiday gift research begins |
| **Dec 2026** | Holiday & Gifting | Winter & Holiday Chapter Books (18) · Best Illustrated Chapter Books (23) · Books That Spark Family Conversations (43) | **Book Club Starter Kit** (New Year prep) | Holiday gifting peak |
| **Jan 2027** | New Year, New Reading Habits | Building a Daily Reading Habit at Home (32) · How to Start a Kids' Book Club (91) · 15 Great Book Club Picks (92) | **Book Club Starter Kit** | New Year reading challenges/resolutions |
| **Feb 2027** | Friendship & Connection | Middle Grade Books About Friendship (5) · Mother-Daughter Book Club Picks (93) · Books That Build Empathy (20) | **Book Club Starter Kit** | Valentine's / connection theme |
| **Mar 2027** | Reading Engagement | What to Do When Your Child Won't Read (33) · 20 Books for Reluctant Readers (3) · Reading by Grade Level Chart (34) | **Family Reading Guide** | Read Across America (early Mar) |
| **Apr 2027** | Libraries & Discovery | Middle Grade Books for Library Collections (81) · National Library Week Program Ideas (90) · How to Run a Library Book Club (85) | **Book Club Starter Kit** | National Library Week (mid-Apr) |
| **May 2027** | Summer Prep | Upper Middle Grade Fantasy Starter List (9) · A Year of Read-Alouds for Homeschoolers (61) · Books Like Percy Jackson (13) | **Summer Reading Challenge** | Summer reading planning begins |
| **Jun 2027** | Summer Kickoff | Fantasy Books for 10-Year-Olds (2) · Adventure Books for Middle Grade (27) · Strong Girl Protagonists (14) | **Summer Reading Challenge** | School's out — peak browsing |

---

## 7. Conversion & Engagement Map

Every page does one of three jobs: **Buy** (move toward purchasing *Cusp Born*), **Subscribe** (Kit signup), or **Adopt** (institutional/classroom/club uptake). Broad content pages prioritize Subscribe (they convert to sales weakly today); *Cusp Born* and institutional pages prioritize Buy/Adopt.

| Page / Location | Primary Goal | Recommended CTA |
|---|---|---|
| Homepage hero | Buy | "Meet *Cusp Born* — the debut fantasy readers ages 8–12 can't put down. **Read an excerpt →**" |
| Homepage secondary band | Subscribe | "Get our free Family Reading Guide + monthly book recommendations. **Join the newsletter →**" |
| *Cusp Born* page — top | Buy | Prominent "**Buy Cusp Born**" buttons (retailer + direct) above the fold |
| *Cusp Born* page — mid | Subscribe | "Love it? Get notified about Lorraine Hawley's next book. **Join the list →**" |
| *Cusp Born* page — educator block | Adopt | "Teachers & librarians: **Download the free Cusp Born Educators & Librarians Kit →**" (Kit-gated) |
| Reading-list articles (inline) | Subscribe | "Want lists like this monthly? **Get our reading newsletter →**" + soft mention of *Cusp Born* where genre-relevant |
| Reading-list articles (end) | Buy | "On this list from McGuffin: ***Cusp Born*** — [short pitch] **See the book →**" (only where it genuinely fits) |
| For Families section | Subscribe | "**Download the free Family Reading Guide**" (Kit signup gate) |
| Homeschool section | Subscribe + Adopt | "**Get the free Homeschool Literature Resource Pack**" → nurture toward *Cusp Born* unit study |
| For Educators section | Adopt + Subscribe | "**Download the Teacher Discussion Guide Collection**" featuring the *Cusp Born* guide as the anchor sample |
| For Libraries section | Adopt | "**Request the Cusp Born Library Kit**" + "Add *Cusp Born* to your collection (ISBN + ordering info)" |
| Book Clubs section | Adopt + Buy | "**Get the free Book Club Starter Kit**" + "Reading *Cusp Born*? Grab the discussion guide →" |
| Downloads hub | Subscribe | Each download = a Kit form. Frame: "Free — just tell us where to send it." |
| Global footer (all pages) | Subscribe | Persistent newsletter form: "Reading recommendations + new releases, monthly." |
| Exit/scroll prompt (articles) | Subscribe | Lightweight "Before you go — grab the free guide" with the page-relevant lead magnet |

**Where to push *Cusp Born* specifically:** the book page (always), any fantasy/adventure/courage/friendship/strong-protagonist reading list, the homeschool novel-study and educator novel-study content, every institutional section, and fantasy/parent-child book-club content. Do **not** force it into off-genre lists (e.g., picture-book or nonfiction content) — credibility as a recommender is the asset that earns the email.

---

## 8. Cusp-Born-Anchored Institutional Play

**The problem this solves.** Broad content earns traffic and emails but converts to *Cusp Born* sales weakly. The one channel where a single title can win real, repeatable adoption is **institutional**: a teacher who adopts *Cusp Born* for a novel study buys a class set and brings it back next year; a librarian who shelves it and runs a program drives circulation and visibility; a book club that picks it generates 8–15 sales plus word-of-mouth. These audiences don't need a catalog — they need *one great book with everything they need to teach or run it already done for them.*

**The flagship asset: the *Cusp Born* Educators & Librarians Kit.** A single polished, free, Kit-gated download (PDF) that makes *Cusp Born* the path of least resistance for any educator or group. Contents:

1. **Discussion guide** — 12–15 open-ended discussion questions organized by section/chapter, suitable for classroom, homeschool, and book club.
2. **Lesson plan aligned to ages 8–12** — 3–5 sessions, with objectives mapped loosely to common ELA skills (theme, character, setting, inference) so teachers can slot it into existing units; note grade-band fit (roughly grades 3–6).
3. **Vocabulary list** — 20–30 words by chapter with kid-friendly definitions and a reproducible activity.
4. **Comprehension questions** — a leveled set (recall → inference → analysis) with an answer key for educators.
5. **Author info sheet** — Lorraine Hawley bio, an interview Q&A suitable for sharing with students, and a note for hosting a virtual or in-person author visit.
6. **Read-aloud tips** — pacing notes, natural stopping points, and "ask the room" prompts for reading *Cusp Born* aloud, plus illustrator notes from Jocie Salveson's artwork.
7. **Logistics one-pager** — ISBN, formats, page count, content/age notes for gatekeepers, bulk/class-set ordering info, and a contact for review copies.

**Distribution.** Anchor it on the *Cusp Born* page (educator block), surface it as the "sample" inside the Teacher Discussion Guide Collection, offer it as the *Cusp Born* Library Kit on For Libraries, and reference it in book-club content. Gate it behind a single Kit form with an audience tag (educator / librarian / homeschool / book club) so the newsletter can nurture each segment differently. Offer **free educator/librarian review copies** behind a short form — this is the highest-leverage spend a one-title publisher can make.

**The template (this is the real point).** Build the kit once, as a structured template:

> `[Title] Educators & Librarians Kit` → Discussion Guide · Lesson Plan (ages X–Y) · Vocabulary · Comprehension Qs + Key · Author Info Sheet · Read-Aloud Tips · Logistics One-Pager

Every future McGuffin title ships with this kit on day one. By the time the catalog is 4–5 books, the institutional channel is a system, not a scramble — and the broad reading-list content built in years 1–2 finally has a catalog to convert against.

---

## 9. Implementation Roadmap

Reader-first throughout. Author/submission tasks are explicitly deprioritized.

### Immediate (Week 1)
- [ ] **Fix the sitemap.** `sitemap.xml` still lists the old author-first URLs (query-letters, publishing, writing-craft, author downloads) and omits the new reader sections. Regenerate it to list `/`, `/cusp-born.html`, `/resources/` and all six sections + `/resources/downloads/`, and demote `/submit.html` priority.
- [ ] Update global nav to the new order: **Books · Authors · For Readers · Resources · About · Submit**; confirm "For Readers" and "Resources" are visually primary.
- [ ] Apply the Section 4 meta titles/descriptions/H1s to the homepage, *Cusp Born* page, and `/resources/`.
- [ ] Stand up Kit forms for all five lead magnets with audience tags; place the newsletter form in the global footer.
- [ ] Add the *Cusp Born* "Buy" CTA above the fold and the educator-block CTA further down.
- [ ] Verify Google Search Console + GA4 are installed and submit the corrected sitemap.

### Short-Term (30 days)
- [ ] Build and publish the **five lead magnets** (Family Reading Guide, Summer Reading Challenge, Homeschool Literature Resource Pack, Book Club Starter Kit, Teacher Discussion Guide Collection).
- [ ] Build the **Cusp Born Educators & Librarians Kit** (Section 8) — this is the highest-value single asset.
- [ ] Publish the **P0 reading lists** (IDs 1, 2, 3, 6, 23) and the P0 family/homeschool/educator cornerstones (31, 47, 63, 65).
- [ ] Write the Kit **welcome sequence** (3–4 emails) that recommends books and introduces *Cusp Born* naturally.
- [ ] Add inline + end-of-article CTAs (Section 7) to every published piece.
- [ ] Set up the educator/librarian **review-copy request** form.

### Medium (90 days)
- [ ] Execute the content calendar through the back-to-school + fall push (Aug–Oct).
- [ ] Reach ~20–25 published resource pages, weighted to P0/P1.
- [ ] Launch monthly newsletter cadence in Kit.
- [ ] Begin targeted outreach: send the Educators & Librarians Kit + review-copy offer to homeschool groups, MG-teacher communities, and youth-services librarian lists.
- [ ] Pursue early reviews/blurbs and add them to the *Cusp Born* page.
- [ ] Review GSC: double down on pages gaining impressions; refresh underperformers.

### Long-Term (6–12 months)
- [ ] Complete the bulk of the 100-idea content engine (prioritize P0/P1; let P3 slide).
- [ ] Grow Kit list to low thousands; segment by audience tag and tailor nurture.
- [ ] Validate the institutional kit with real classroom/library/club adoptions; collect case studies/testimonials.
- [ ] **Prepare for catalog growth:** finalize the repeatable per-title kit template so book #2 launches with full reader + institutional assets on day one.
- [ ] Retire/redirect any lingering author-first pages that no longer fit; keep `/submit` lean.
- [ ] Reassess keyword priorities with a year of GSC data.

---

## 10. Measurement

Track against the business goals in priority order. Review monthly; formal quarterly read-out.

| Goal | Primary KPI(s) | Secondary KPI(s) | Tool(s) |
|---|---|---|---|
| 1. Book sales | *Cusp Born* units sold (direct + retailer-referred); revenue | Add-to-cart / buy-button clicks; retailer click-throughs | Retailer/sales dashboards, GA4 (outbound + event tracking) |
| 2. Reader engagement | Organic sessions; pages/session; avg. engagement time on resource pages | Returning visitors; scroll depth on articles | GA4 |
| 3. Newsletter subscribers | Net new Kit subscribers/month; total list size | Signup conversion rate by lead magnet; form views→signups | Kit, GA4 |
| 4. Discoverability | Organic clicks & impressions; # keywords ranking top 20; top landing pages | Avg. position for P0 keywords; indexed page count | Google Search Console |
| 5. Homeschool adoption | Homeschool Resource Pack downloads; homeschool-tagged subscribers | Cusp Born unit-study downloads; homeschool review-copy requests | Kit (tags), GA4 |
| 6. Educator adoption | Educators & Librarians Kit downloads; educator-tagged subscribers | Teacher Discussion Guide Collection downloads; class-set / review-copy inquiries | Kit (tags), form submissions |
| 7. Library adoption | Library Kit requests; librarian-tagged subscribers | Library review-copy requests; collection/ordering inquiries | Kit (tags), form submissions |
| 8. Book-club adoption | Book Club Starter Kit downloads; *Cusp Born* discussion-guide downloads | Book-club-tagged subscribers; multi-copy orders | Kit (tags), sales dashboard |
| 9. Authority | Total ranking keywords; referring domains/backlinks; branded search volume | Newsletter open/click rates; repeat resource downloads | GSC, GA4, Kit |

**Reporting cadence & guardrails.**
- **Weekly (light):** new subscribers, top landing pages, any *Cusp Born* sales spikes.
- **Monthly:** the full table above; identify the month's best-performing content and lead magnet.
- **Quarterly:** keyword-priority reassessment, content-calendar adjustment, institutional-adoption review.
- **Honesty check:** expect broad reading-list pages to dominate traffic and signups while contributing little *direct* revenue early on — judge them on **list growth**, and judge *Cusp Born* pages and institutional kits on **sales and adoptions**. Do not "fix" a high-traffic list because it isn't selling books; that's its job working as designed. The sales engine is the email list plus the institutional kits, compounding as the catalog grows.
