/* McGuffin Press — lead-magnet capture wiring
   Each form.capture[data-resource] submits the email to Kit, then sends the
   reader to thank-you.html?r=<slug> where the matching printable is delivered. */
(function () {
  var forms = document.querySelectorAll('form.capture[data-resource]');
  forms.forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var slug = f.getAttribute('data-resource');
      var btn = f.querySelector('[type="submit"]');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
      // Fire the subscribe to Kit (no-cors: request goes through, response opaque)
      try { fetch(f.action, { method: 'POST', body: new FormData(f), mode: 'no-cors' }); } catch (err) {}
      // Always advance the reader to their download
      window.location.href = 'thank-you.html?r=' + encodeURIComponent(slug);
    });
  });
})();
